import base64
import json
import os
import urllib
from urllib import request, parse
import sys
import logging
import os
import boto3
from boto3.dynamodb.conditions import Key, Attr
import botocore
from botocore.exceptions import ClientError
import datetime
import csv

TWILIO_SMS_URL = os.environ.get("TWILIO_SMS_URL")
TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN")
TWILIO_CONTACT_NO = os.environ.get("TWILIO_CONTACT_NO")

dynamodb = boto3.resource("dynamodb", region_name='us-east-1')

tableRead = dynamodb.Table('RapidSMSQuestion')
tableWrite = dynamodb.Table('RapidSMSResponse')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

BUCKET_NAME = 'rapid-sms' # replace with your bucket name
KEY = 'ParticipantRecord.csv' # replace with your object key
s3 = boto3.resource('s3')

def lambda_handler(event, context):
    logger.info(event)
    if event['SmsStatus'] == 'received':
        receivingFromUser(event)
    elif event['SmsStatus'] == 'firstText':
        firstTextToUser(event)
    else:
        return "Incorrect Call"

def makepublic():
    bucket = s3.Bucket(BUCKET_NAME)
    object = bucket.Object(KEY)
    bucket.Acl().put(ACL='public-read')
    object.Acl().put(ACL='public-read')

def uploadfile():
    s3 = boto3.client('s3')
    filename = KEY
    bucket_name = BUCKET_NAME
    s3.upload_file("/tmp/"+filename, bucket_name, filename)
    makepublic()

def pushDataOnS3(dataStorage):
    try:
        s3.Bucket(BUCKET_NAME).download_file(KEY, "/tmp/"+KEY)
        with open(r'/tmp/ParticipantRecord.csv', 'a') as f:
            writer = csv.writer(f)
            writer.writerow(dataStorage)
        uploadfile()
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            print("The object does not exist.")
        else:
            raise
        

def updateWriteDynamoDB(contact_no, member, questionNo, dictOfResponses):
    questionNo = str(questionNo)
    response = tableWrite.update_item(
    Key={
        'contact_no': contact_no,
        'member': member
    },
    UpdateExpression="set QuestionResponse = :r",
    ExpressionAttributeValues={
        ':r': {
            "ResponsesRecorded": dictOfResponses,
            questionNo: " "
        }
    },
    ReturnValues="UPDATED_NEW"
    )

def inactiveMember(participant_id,contact_no, member, questionNo, dictOfResponses):
    dataStorage = []
    dataStorage.append(participant_id)
    #dataStorage.append(member)
    dataStorage.append(dictOfResponses)
    pushDataOnS3(dataStorage)
    questionNo = str(questionNo)
    response = tableWrite.delete_item(
    Key={
        'contact_no': contact_no,
        'member': "ACTIVE"
    }
    )

def iterativeText(event,protocolId, questionNo,dictOfResponses):
    to_number = "+"+event["From"][3:]
    logger.info(to_number)
    from_number = "+18548886385"
    body = readDynamoDB(protocolId,questionNo)
    populated_url = TWILIO_SMS_URL.format(TWILIO_ACCOUNT_SID)
    post_params = {"To": to_number, "From": from_number, "Body": body}
 
    # encode the parameters for Python's urllib
    data = parse.urlencode(post_params).encode()
    req = request.Request(populated_url)
 
    # add authentication header to request based on Account SID + Auth Token
    authentication = "{}:{}".format(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
    base64string = base64.b64encode(authentication.encode('utf-8'))
    req.add_header("Authorization", "Basic %s" % base64string.decode('ascii'))
    if body == "Thank you":
        participant_id = readParticipantData(to_number)
        inactiveMember(participant_id,to_number, "INACTIVE", questionNo, dictOfResponses)
    else:
        updateWriteDynamoDB(to_number, "ACTIVE", questionNo, dictOfResponses)
    try:
        # perform HTTP POST request
        with request.urlopen(req, data) as f:
            print("Twilio returned {}".format(str(f.read().decode('utf-8'))))
    except Exception as e:
        # something went wrong!
        return e




def sendErrorMessage(TO):
    to_number = TO
    from_number = "+18548886385"
    body = "Please provide the correct input"
    populated_url = TWILIO_SMS_URL.format(TWILIO_ACCOUNT_SID)
    post_params = {"To": to_number, "From": from_number, "Body": body}
 
    # encode the parameters for Python's urllib
    data = parse.urlencode(post_params).encode()
    req = request.Request(populated_url)
 
    # add authentication header to request based on Account SID + Auth Token
    authentication = "{}:{}".format(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
    base64string = base64.b64encode(authentication.encode('utf-8'))
    req.add_header("Authorization", "Basic %s" % base64string.decode('ascii'))
    #writeDynamoDB(1,"+19177426612")
    try:
        # perform HTTP POST request
        with request.urlopen(req, data) as f:
            print("Twilio returned {}".format(str(f.read().decode('utf-8'))))
    except Exception as e:
        # something went wrong!
        return e

def noResponseRquired(TO):
    to_number = TO
    from_number = "+18548886385"
    body = "No Response Required"
    populated_url = TWILIO_SMS_URL.format(TWILIO_ACCOUNT_SID)
    post_params = {"To": to_number, "From": from_number, "Body": body}
 
    # encode the parameters for Python's urllib
    data = parse.urlencode(post_params).encode()
    req = request.Request(populated_url)
 
    # add authentication header to request based on Account SID + Auth Token
    authentication = "{}:{}".format(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
    base64string = base64.b64encode(authentication.encode('utf-8'))
    req.add_header("Authorization", "Basic %s" % base64string.decode('ascii'))
    try:
        # perform HTTP POST request
        with request.urlopen(req, data) as f:
            print("Twilio returned {}".format(str(f.read().decode('utf-8'))))
    except Exception as e:
        # something went wrong!
        return e

def receivingFromUser(event):
    FROM = "+"+event["From"][3:]
    response = tableWrite.query(
        KeyConditionExpression = Key("contact_no").eq(FROM) & Key("member").eq("ACTIVE")
    )
    if (response["Count"] == 1):
        dictOfResponses = response["Items"][0]["QuestionResponse"]
        for qestionNo in dictOfResponses:
            if qestionNo == "ResponsesRecorded":
                continue
            if dictOfResponses[qestionNo] == " ":
                responsesAccepted = verifyResponse(1, int(qestionNo))
                ACCEPTED = 0
                for acceptance in responsesAccepted:
                    if acceptance.lower() == event["Body"].lower() or acceptance == "Any Value":
                        ACCEPTED = 1
                        dictOfResponses[qestionNo] = event["Body"]
                        iterativeText(event,1, int(responsesAccepted[acceptance]), dictOfResponses)
                        break
                if ACCEPTED == 0:
                    sendErrorMessage(FROM)
                    break
                logger.info(responsesAccepted)
        logger.info(dictOfResponses)
    else:
        noResponseRquired(FROM)

def firstTextToUser(event):
    for participants in event['PAYLOAD']:
        to_number = participants['CONTACT_NO']
        from_number = "+18548886385"
        body = readDynamoDB(1,1)
        print(body)
        populated_url = TWILIO_SMS_URL.format(TWILIO_ACCOUNT_SID)
        post_params = {"To": to_number, "From": from_number, "Body": body}
     
        # encode the parameters for Python's urllib
        data = parse.urlencode(post_params).encode()
        req = request.Request(populated_url)
     
        # add authentication header to request based on Account SID + Auth Token
        authentication = "{}:{}".format(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        base64string = base64.b64encode(authentication.encode('utf-8'))
        req.add_header("Authorization", "Basic %s" % base64string.decode('ascii'))
        writeDynamoDB(participants['paricipant_id'],to_number)
        try:
            # perform HTTP POST request
            with request.urlopen(req, data) as f:
                print("Twilio returned {}".format(str(f.read().decode('utf-8'))))
        except Exception as e:
            # something went wrong!
            return e

def verifyResponse(protocolId,questionNo):
    try:
        response = tableRead.get_item(
            Key={
                'protocolId': protocolId,
                'questionNo':questionNo
            }
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        item = response['Item']
        print("GetItem succeeded:")
        return item['response']


def readDynamoDB(protocolId,questionNo):
    try:
        response = tableRead.get_item(
            Key={
                'protocolId': protocolId,
                'questionNo':questionNo
            }
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        item = response['Item']
        print("GetItem succeeded:")
        return item['question']
    
def readParticipantData(contact_no):
    try:
        response = tableWrite.get_item(
            Key={
                'contact_no': contact_no,
                'member':"ACTIVE"
            }
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        item = response['Item']
        print("GetParticipantID succeeded:")
        return item['paricipant_id']
        
        
def writeDynamoDB(paricipant_id,contact_no):
    currentTime = datetime.datetime.now()
    current = currentTime.strftime('%Y-%m-%d %H:%M')
    response = tableWrite.put_item(
       Item={
            'contact_no': contact_no,
            'dateTime': current,
            'paricipant_id': paricipant_id,
            'QuestionResponse':{
                '1':" "
            },
            'member':"ACTIVE"
        }
    )
    print("Done")
    
    
    
    
    
    
    
    
    
    
    
    

    
