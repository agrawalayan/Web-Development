import sys
import logging
import pymysql
import os
import json
#import pytz
import datetime
import time

rds_host  = os.environ.get("RDS_HOST")
name = os.environ.get("USERNAME")
password = os.environ.get("PASSWORD")
db_name = os.environ.get("DB_NAME")

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except:
    logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
    sys.exit()

logger.info("SUCCESS: Connection to RDS mysql instance succeeded")

def handler(event, context):
    if event == {}:
        return
    elif event['function_call'] == "fetch_view_enrolments":
        return getViewEnrolments(event)
    elif event['function_call'] == "fetch_enrolment_id":
        return getEnrolmentId(event)
    elif event['function_call'] == "fetch_participant_id":
        return getParticipantId(event)
    elif event['function_call'] == "fetch_survey_id":
        return getSurveyId(event)
    elif event['function_call'] == "push_survey_data":
        return setSurveyTask(event)
    elif event['function_call'] == "push_enrolment_data":
        return setEnrolmentTask(event)
    elif event['function_call'] == "push_participants":
        return setParticipants(event)
    elif event['function_call'] == "fetch_enrolment_names":
        return getEnrolmentNames(event)
    elif event['function_call'] == "fetch_view_tasks":
        return getViewSurveyTasks(event)
    elif event['function_call'] == "fetch_enrolment_metadata":
        return getEnrolmentMetadata(event)
    elif event['function_call'] == "remove_enrolment":
        return removeEnrolment(event)
    elif event['function_call'] == "remove_survey":
        return removeSurvey(event)
    elif event['function_call'] == "getAllEnrollmentNames":
        return getAllEnrollmentNames(event)
    else:
        return "Incorrect Function call"


def getViewEnrolments(event):
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    Enroled = []
    SELECT_QUERY = "SELECT enrolment_id, enrolment_name, COUNT(paricipant_id)  FROM  enrol GROUP BY enrolment_id;"
    with conn.cursor() as cur:
        cur.execute(SELECT_QUERY)
        for row in cur:
            response = {
                "Enrolment_Id":row[0],
                "Enrolment_Name":row[1],
                "Participants_Count":row[2],
                }
            Enroled.append(response)
    conn.close()
    return Enroled

def getEnrolmentId(event):
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    SELECT_QUERY = "SELECT enrolment_id FROM enrol ORDER BY enrolment_id DESC LIMIT 1;"
    with conn.cursor() as cur:
        cur.execute(SELECT_QUERY)
        for row in cur:
            response = {
                "Enrolment_Id":row[0]
            }
            conn.close()
            return response
    return {"Enrolment_Id":0}

def getEnrolmentNames(event):
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    SELECT_QUERY = "SELECT enrolment_name from enrol WHERE enrolment_id = {};".format(event['enrolment_id'])
    with conn.cursor() as cur:
        cur.execute(SELECT_QUERY)
        for row in cur:
            response = {
                "Enrolment_name":row[0]
            }
            conn.close()
            print(response)
            return response

def getAllEnrollmentNames(event):
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    ALL_NAMES = []
    SELECT_QUERY = "SELECT enrolment_id, enrolment_name from enrolment;"
    with conn.cursor() as cur:
        cur.execute(SELECT_QUERY)
        for row in cur:
            response = {
                "Enrolment_id": row[0],
                "Enrolment_name":row[1]
            }
            ALL_NAMES.append(response)
    conn.close()
    return ALL_NAMES

def getEnrolmentMetadata(event):
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    SELECT_QUERY = "select enrolment_name, enrolment_open, enrolment_close, enrolment_expiry from enrolment WHERE enrolment_id = {};".format(event['enrolment_id'])
    with conn.cursor() as cur:
        cur.execute(SELECT_QUERY)
        for row in cur:
            logger.info(row)
            response = {
                "Enrolment_name": row[0],
                "Enrolment_Open": str(row[1]),
                "Enrolment_Close": str(row[2]),
                "Enrolment_Expiry": str(row[3])
            }
            conn.close()
            return response

def removeEnrolment(event):
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    logger.info(event)
    DELETE_QUERY_SURVEY_TABLE = "DELETE from survey WHERE enrolment_id = {};".format(event['enrolment_id'])
    DELETE_QUERY_ENROL_TABLE = "DELETE from enrol WHERE enrolment_id = {};".format(event['enrolment_id'])
    DELETE_QUERY_ENROLMENT_TABLE = "DELETE from enrolment WHERE enrolment_id = {};".format(event['enrolment_id'])
    logger.info(DELETE_QUERY_SURVEY_TABLE)
    logger.info(DELETE_QUERY_ENROL_TABLE)
    with conn.cursor() as cur:
        cur.execute(DELETE_QUERY_SURVEY_TABLE)
        conn.commit()
        cur.execute(DELETE_QUERY_ENROLMENT_TABLE)
        conn.commit()
        cur.execute(DELETE_QUERY_ENROL_TABLE)
        conn.commit()
        conn.close()
        return {"Status":"Success"}
    conn.close()
    return {"Status":"Failed"}


def setEnrolmentTask(event):
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    enrolment_id = event['enrolment_id']
    enrolment_name = event['enrolment_name']
    enrolment_open = event['enrolment_open']
    enrolment_close = event['enrolment_close']
    enrolment_expiry = event['enrolment_expiry']
    INSERT_QUERY_ENROL = "INSERT INTO enrol (enrolment_id,enrolment_name) VALUES({},'{}');".format(enrolment_id,enrolment_name)
    #INSERT_QUERY_SURVEY = "INSERT INTO survey (enrolment_id, enrolment_name, enrolment_open, enrolment_close,enrolment_expiry)\
    #    VALUES({},'{}','{}','{}','{}');".format(enrolment_id, enrolment_name, enrolment_open, 
    #    enrolment_close,enrolment_expiry)
    INSERT_QUERY_ENROLMENT = "INSERT INTO enrolment (enrolment_id, enrolment_name, enrolment_open, enrolment_close,enrolment_expiry)\
        VALUES({},'{}','{}','{}','{}');".format(enrolment_id, enrolment_name, enrolment_open, 
        enrolment_close,enrolment_expiry)    
    with conn.cursor() as cur:
        cur.execute(INSERT_QUERY_ENROL)
        conn.commit()
        cur.execute(INSERT_QUERY_ENROLMENT)
        conn.commit()
        conn.close()
        return {"Enrolled":"Success"}
    conn.close()
    return {"Enrolled":"Failed"}

def setParticipants(event):
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    enrolment_id = event['enrolment_id']
    participant_id = event['participant_id']
    enrolment_name = event['enrolment_name']
    participant_name = event['participant_name']
    participant_contact_no = event['participant_contact']
    
    INSERT_QUERY_ENROL = "INSERT INTO enrol (enrolment_id,paricipant_id,enrolment_name,participant_name, participant_contact) \
        VALUES({},{},'{}','{}','{}');".format(enrolment_id, participant_id, enrolment_name, participant_name, participant_contact_no)
    #INSERT_QUERY_SURVEY = "UPDATE survey SET paricipant_id = {} WHERE enrolment_id = {} AND paricipant_id IS NULL;".format(participant_id, enrolment_id)
    with conn.cursor() as cur:
        cur.execute(INSERT_QUERY_ENROL)
        conn.commit()
        conn.close()
        return {"Status":"Success"}
    conn.close()
    return {"Status":"Failed"}

def getViewSurveyTasks(event):
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    Tasks = []
    SELECT_QUERY = "select task_name,protocol_name,enrolment_name,survey_id from survey GROUP BY survey_id;"
    with conn.cursor() as cur:
        cur.execute(SELECT_QUERY)
        for row in cur:
            response = {
                "Task_name": row[0],
                "Protocol_name": row[1],
                "Enrolment_name": row[2],
                "Survey_id": row[3]
            }
            Tasks.append(response)
    conn.close()
    return Tasks


def getParticipantId(event):
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    SELECT_QUERY = "SELECT paricipant_id FROM enrol ORDER BY paricipant_id DESC LIMIT 1;"
    with conn.cursor() as cur:
        cur.execute(SELECT_QUERY)
        for row in cur:
            response = {
                "Participant_Id":row[0]
            }
            conn.close()
            return response

def getSurveyId(event):
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    SELECT_QUERY = "SELECT survey_id FROM survey ORDER BY survey_id DESC LIMIT 1;"
    with conn.cursor() as cur:
        cur.execute(SELECT_QUERY)
        for row in cur:
            response = {
                "Survey_id": row[0]
            }
            conn.close()
            return response
        return {"Survey_id": 0}
    
def setSurveyTask(event):
    print(event)
    PARTICIPANTS = []
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    SELECT_QUERY = "select paricipant_id from enrol where enrolment_id = {};".format(event["enrolment_id"])
    with conn.cursor() as cur:
        cur.execute(SELECT_QUERY)
        for row in cur:
            PARTICIPANTS.append(row[0])
    conn.close()
    print(PARTICIPANTS)
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    ENROLMENT_DETAILS = []
    SELECT_QUERY = "select enrolment_name,enrolment_open,enrolment_close,enrolment_expiry from enrolment where enrolment_id = {};".format(event["enrolment_id"])
    with conn.cursor() as cur:
        cur.execute(SELECT_QUERY)
        for row in cur:
            ENROLMENT_DETAILS.append(row[0])
            ENROLMENT_DETAILS.append(row[1])
            ENROLMENT_DETAILS.append(row[2])
            ENROLMENT_DETAILS.append(row[3])
            break
    conn.close()
    print(ENROLMENT_DETAILS)
    start_date = event["time_rule"]["run_date"]
    end_date = event["time_rule"]["until"]
    timezone = event["time_rule"]["timezone"]
    runningTime = event["time_rule"]["run_times"]
    timeStamp = []
    for times in runningTime:
        s = start_date + " "+ times
        timeStamp.append(time.mktime(datetime.datetime.strptime(s, "%Y-%m-%d %H:%M").timetuple())+14400)
    print(timeStamp)
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    for participants in PARTICIPANTS:
        if participants == None:
            continue
        for time_stamp in range(len(timeStamp)):
            INSERT_QUERY = "INSERT INTO survey VALUES({},{},'{}','{}','{}',\
            '{}',{},'{}','{}','{}','{}','{}','{}','{}','{}');".format(event['enrolment_id'], \
            participants,ENROLMENT_DETAILS[0],ENROLMENT_DETAILS[1],ENROLMENT_DETAILS[2],\
            ENROLMENT_DETAILS[3], event['survey_id'], event['task_name'], event['protocol_name'],\
            runningTime[time_stamp],start_date,end_date,1,"ACTIVE",timeStamp[time_stamp])
            with conn.cursor() as cur:
                cur.execute(INSERT_QUERY)
                conn.commit()


def removeSurvey(event):
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    logger.info(event)
    DELETE_QUERY_SURVEY_TABLE = "DELETE from survey WHERE survey_id = {};".format(event['survey_id'])
    with conn.cursor() as cur:
        cur.execute(DELETE_QUERY_SURVEY_TABLE)
        conn.commit()
        conn.close()
        return {"Status":"Success"}
    conn.close()
    return {"Status":"Failed"}