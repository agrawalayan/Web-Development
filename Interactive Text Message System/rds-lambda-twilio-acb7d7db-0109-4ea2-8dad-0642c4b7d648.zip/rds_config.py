#config file containing credentials for rds mysql instance
db_username = "smsurveyadmin"
db_password = "csulQnyB6Ky6"
db_name = "enrolmentDB"
