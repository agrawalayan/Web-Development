import sys
import logging
import pymysql
import os
import datetime
import boto3
import json
import time

rds_host  = os.environ.get("RDS_HOST")
name = os.environ.get("USERNAME")
password = os.environ.get("PASSWORD")
db_name = os.environ.get("DB_NAME")
lambda_client = boto3.client('lambda')
logger = logging.getLogger()
logger.setLevel(logging.INFO)
lambda_client = boto3.client('lambda')
try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except:
    logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
    sys.exit()

logger.info("SUCCESS: Connection to RDS mysql instance succeeded")

def handler(event, context):
    currentTime = int(time.time())
    print(currentTime)
    SELECT_QUERY = "SELECT paricipant_id, protocol_name FROM survey where member ='ACTIVE' AND timestamp<{};".format(currentTime) 
    ACTIVE_PARTICIPANTS = []
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    with conn.cursor() as cur:
        cur.execute(SELECT_QUERY)
        for row in cur:
            participants = {
                "paricipant_id": row[0],
                "protocol_name": row[1]
            }
            ACTIVE_PARTICIPANTS.append(participants)
    conn.close()
    print(ACTIVE_PARTICIPANTS)
    PARTICIPANTS_DETAILS = []
    PAYLOAD_OBJECT = {}
    for participants in ACTIVE_PARTICIPANTS:
        FETCH_CONTACT_NO = "SELECT participant_contact from enrol where paricipant_id = {};".format(participants["paricipant_id"])
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
        with conn.cursor() as cur:
            cur.execute(FETCH_CONTACT_NO)
            for row in cur:
                participants_details = {
                    "paricipant_id": participants["paricipant_id"],
                    "CONTACT_NO": row[0],
                    "protocol_name": participants["protocol_name"]
                }
                PARTICIPANTS_DETAILS.append(participants_details)
                break
        conn.close()
    print(PARTICIPANTS_DETAILS)
    if PARTICIPANTS_DETAILS:
        PAYLOAD_OBJECT["PAYLOAD"] = PARTICIPANTS_DETAILS
        PAYLOAD_OBJECT["SmsStatus"] = "firstText"
        print(PAYLOAD_OBJECT)
        JSON_OBJECT = json.dumps(PAYLOAD_OBJECT)
        trigger_lambda = lambda_client.invoke(FunctionName="twilio_interface",
                                               InvocationType='Event',
                                               Payload = JSON_OBJECT
                                               )
        for inactive_participants in ACTIVE_PARTICIPANTS:
            UPDATE_QUERY = "UPDATE survey SET member = 'INACTIVE' where paricipant_id = {} AND timestamp<{};".format(inactive_participants["paricipant_id"],currentTime)
            conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
            with conn.cursor() as cur:
                cur.execute(UPDATE_QUERY)
                conn.commit()
            conn.close()
    
